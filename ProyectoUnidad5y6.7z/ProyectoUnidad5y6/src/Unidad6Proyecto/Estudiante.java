
package Unidad6Proyecto;

import java.io.Serializable;

public class Estudiante implements Serializable {
    private String NoControl;
    private String Nombre;
    private double Promedio;

  
    public Estudiante(){
        NoControl = "0";
        Nombre = "sin nombre";
        Promedio = 0;
    }
    public Estudiante(String noControl, String nombre, double promedio) {
        this.NoControl = noControl;
        this.Nombre = nombre;
        this.Promedio = promedio;
    }

    public String getNoControl() {
        return NoControl;
    }

    public void setNoControl(String noControl) {
        this.NoControl = noControl;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        this.Nombre = nombre;
    }

    public double getPromedio() {
        return Promedio;
    }

    public void setPromedio(double promedio) {
        this.Promedio = promedio;
    }

    @Override
    public String toString() {
        return NoControl + "  " + Nombre + "  " + Promedio;
    }
    
}