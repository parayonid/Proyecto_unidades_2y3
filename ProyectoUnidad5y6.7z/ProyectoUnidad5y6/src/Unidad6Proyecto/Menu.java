package Unidad6Proyecto;

import java.io.*;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Menu extends javax.swing.JFrame {
    
    String nombreArchivo;
    String nombreBinario;
    int[][] matrizCalificaciones = new int[21][7];
    String[][] matrizEstudiantes = new String[21][2];
    boolean archivoCargado = false;
    boolean archivoCalculado = false;
    boolean binarioGuardado = false;
    boolean excelencia = false;
    boolean estadisticas = false;
    boolean mostrar = false;

    public Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        botonEstadisticas = new javax.swing.JButton();
        botonCargar = new javax.swing.JButton();
        botonCalcular = new javax.swing.JButton();
        botonGuardar = new javax.swing.JButton();
        botonMostrar = new javax.swing.JButton();
        botonExcelencia = new javax.swing.JButton();
        botonSalir = new javax.swing.JButton();
        botonReportes = new javax.swing.JButton();
        campoNombreArchivo = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        campoNombreBinario = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(240, 229, 216));

        botonEstadisticas.setBackground(new java.awt.Color(242, 132, 130));
        botonEstadisticas.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        botonEstadisticas.setForeground(new java.awt.Color(250, 250, 250));
        botonEstadisticas.setText("Estadísticas");
        botonEstadisticas.setBorder(null);
        botonEstadisticas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEstadisticasActionPerformed(evt);
            }
        });

        botonCargar.setBackground(new java.awt.Color(242, 132, 130));
        botonCargar.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        botonCargar.setForeground(new java.awt.Color(250, 250, 250));
        botonCargar.setText("Cargar");
        botonCargar.setBorder(null);
        botonCargar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCargarActionPerformed(evt);
            }
        });

        botonCalcular.setBackground(new java.awt.Color(242, 132, 130));
        botonCalcular.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        botonCalcular.setForeground(new java.awt.Color(250, 250, 250));
        botonCalcular.setText("Calcular");
        botonCalcular.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        botonCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCalcularActionPerformed(evt);
            }
        });

        botonGuardar.setBackground(new java.awt.Color(242, 132, 130));
        botonGuardar.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        botonGuardar.setForeground(new java.awt.Color(250, 250, 250));
        botonGuardar.setText("Guardar");
        botonGuardar.setBorder(null);
        botonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardarActionPerformed(evt);
            }
        });

        botonMostrar.setBackground(new java.awt.Color(242, 132, 130));
        botonMostrar.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        botonMostrar.setForeground(new java.awt.Color(250, 250, 250));
        botonMostrar.setText("Mostrar");
        botonMostrar.setBorder(null);
        botonMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonMostrarActionPerformed(evt);
            }
        });

        botonExcelencia.setBackground(new java.awt.Color(242, 132, 130));
        botonExcelencia.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        botonExcelencia.setForeground(new java.awt.Color(250, 250, 250));
        botonExcelencia.setText("Excelencia");
        botonExcelencia.setBorder(null);
        botonExcelencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonExcelenciaActionPerformed(evt);
            }
        });

        botonSalir.setBackground(new java.awt.Color(242, 132, 130));
        botonSalir.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        botonSalir.setForeground(new java.awt.Color(250, 250, 250));
        botonSalir.setText("Salir");
        botonSalir.setBorder(null);
        botonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSalirActionPerformed(evt);
            }
        });

        botonReportes.setBackground(new java.awt.Color(242, 132, 130));
        botonReportes.setFont(new java.awt.Font("Raleway", 1, 24)); // NOI18N
        botonReportes.setForeground(new java.awt.Color(250, 250, 250));
        botonReportes.setText("Reportes");
        botonReportes.setBorder(null);
        botonReportes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonReportesActionPerformed(evt);
            }
        });

        campoNombreArchivo.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N

        jLabel1.setBackground(new java.awt.Color(51, 51, 51));
        jLabel1.setFont(new java.awt.Font("Raleway", 1, 22)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(242, 132, 130));
        jLabel1.setText("Nombre del archivo de texto");

        campoNombreBinario.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Raleway", 1, 22)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(242, 132, 130));
        jLabel2.setText("Nombre del archivo binario");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(campoNombreBinario, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addComponent(botonReportes, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(campoNombreArchivo, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(43, 43, 43)
                        .addComponent(botonMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonExcelencia, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(botonCargar, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(284, 284, 284)
                        .addComponent(botonCalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(botonEstadisticas, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(0, 0, 0)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoNombreArchivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonExcelencia, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonCargar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonCalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonEstadisticas, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(campoNombreBinario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonReportes, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonCargarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCargarActionPerformed
        nombreArchivo = campoNombreArchivo.getText();
        try {
            Scanner leerEstudiantes = new Scanner(new File(nombreArchivo + ".txt"));

            for (int i = 0; i < 20; i++) {
                String[] valores = leerEstudiantes.nextLine().split(",");
                for (int j = 0; j < 2; j++) {
                    matrizEstudiantes[i][j] = valores[j];
                }
            }

            Scanner leerCalificaciones = new Scanner(new File(nombreArchivo + ".txt"));

            for (int i = 0; i < 20; i++) {
                String[] valores = leerCalificaciones.nextLine().split(",");
                for (int j = 2; j < 8; j++) {
                    if (valores[j].equals("NA")) {
                        valores[j] = "0";
                    }
                    matrizCalificaciones[i][j - 2] = Integer.parseInt(valores[j]);
                }
            }

            JOptionPane.showMessageDialog(null, "Archivo cargado con exito");
            this.archivoCargado = true;
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        campoNombreArchivo.setText(null);

    }//GEN-LAST:event_botonCargarActionPerformed

    private void botonCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCalcularActionPerformed
        if (archivoCargado) {
            int acum = 0;

            //Promedio por estudiante
            for (int i = 0; i < matrizCalificaciones.length - 1; i++) {
                for (int j = 0; j < matrizCalificaciones[i].length - 1; j++) {

                    acum += matrizCalificaciones[i][j];

                }
                matrizCalificaciones[i][matrizCalificaciones[i].length - 1] = acum / 6;
                acum = 0;
            }

            //Promedio por materia
            for (int i = 0; i < 6; i++) {
                for (int j = 0; j < 20; j++) {
                    acum += matrizCalificaciones[j][i];
                }
                matrizCalificaciones[matrizCalificaciones.length - 1][i] = acum / 20;
                acum = 0;

            }

            //Promedio general
            for (int i = 0; i < 6; i++) {
                acum += matrizCalificaciones[matrizCalificaciones.length - 1][i];
                if (i == 5) {
                    matrizCalificaciones[matrizCalificaciones.length - 1][matrizCalificaciones[i].length - 1] = acum / 6;
                }
            }
            JOptionPane.showMessageDialog(null, "Promedios por materia, alumno y general calculado con exito.");

            for (int i = 0; i < matrizCalificaciones.length; i++) {
                for (int j = 0; j < matrizCalificaciones[i].length; j++) {
                    System.out.print("  " + matrizCalificaciones[i][j]);
                }
                System.out.println("");
            }
            this.archivoCalculado = true;
        } else {
            JOptionPane.showMessageDialog(null, "Por favor cargue un archivo de texto para poder calcular.");
        }


    }//GEN-LAST:event_botonCalcularActionPerformed

    private void botonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardarActionPerformed
        if (archivoCalculado) {
            nombreBinario = campoNombreBinario.getText();
            try ( ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nombreBinario + ".bin"))) {
                for (int i = 0; i < 20; i++) {
                    String noCtl = matrizEstudiantes[i][0];
                    String nombre = matrizEstudiantes[i][1];
                    double promedio = matrizCalificaciones[i][6];
                    Estudiante estudiante = new Estudiante(noCtl, nombre, promedio);
                    oos.writeObject(estudiante);
                }

                campoNombreBinario.setText(null);
                this.nombreBinario = nombreBinario + ".bin";
                JOptionPane.showMessageDialog(null, "Archivo guardado con exito");
                this.binarioGuardado = true;
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error guardando el archivo " + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "Por favor haga los calculos antes de guardar un archivo binario");
        }

    }//GEN-LAST:event_botonGuardarActionPerformed

    private void botonExcelenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonExcelenciaActionPerformed
        if (binarioGuardado) {
            String salida = "";

            boolean otro = true;

            try {
                FileInputStream archivo
                        = new FileInputStream(nombreBinario);
                ObjectInputStream entrada = new ObjectInputStream(archivo);
                while (otro) {
                    Estudiante estudiante = new Estudiante();
                    try {
                        estudiante = (Estudiante) entrada.readObject();
                        if (estudiante.getPromedio() >= 90) {
                            salida += estudiante.toString() + "\n";
                        }

                    } catch (IOException io) {
                        JOptionPane.showMessageDialog(null, salida);
                        otro = false;
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
                archivo.close();
                excelencia = true;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al abrir el archivo: "
                        + nombreBinario);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Para mostrar la excelencia, guarde el archivo antes");
        }

    }//GEN-LAST:event_botonExcelenciaActionPerformed

    private void botonMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonMostrarActionPerformed
        if (binarioGuardado) {
            String salida = "";

            boolean otro = true;

            try {
                FileInputStream archivo
                        = new FileInputStream(nombreBinario);
                ObjectInputStream entrada = new ObjectInputStream(archivo);
                while (otro) {
                    Estudiante estudiante = new Estudiante();
                    try {
                        estudiante = (Estudiante) entrada.readObject();
                        salida += estudiante.toString() + "\n";
                    } catch (IOException io) {
                        JOptionPane.showMessageDialog(null, salida);
                        otro = false;
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
                archivo.close();
                mostrar = true;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al abrir el archivo: "
                        + nombreBinario);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Para mostrar primero guarde el archivo binario");
        }


    }//GEN-LAST:event_botonMostrarActionPerformed

    private void botonEstadisticasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEstadisticasActionPerformed
        if (binarioGuardado) {
            JOptionPane.showMessageDialog(null, "Calculo Diferencial: " + matrizCalificaciones[20][0]
                    + "\nFundamentos de programacion: " + matrizCalificaciones[20][1]
                    + "\nMatematicas Discretas: " + matrizCalificaciones[20][2]
                    + "\nIntroducción a las TICS: " + matrizCalificaciones[20][3]
                    + "\nTaller de ética: " + matrizCalificaciones[20][4]
                    + "\nFundamentos de investigacion" + matrizCalificaciones[20][5]
                    + "\nPromedio General: " + matrizCalificaciones[20][6]);
            estadisticas = true;
        } else {
            JOptionPane.showMessageDialog(null, "Para mostrar estadisticas, primero guarde el archivo binario.");
        }

    }//GEN-LAST:event_botonEstadisticasActionPerformed

    private void botonReportesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonReportesActionPerformed
        if (binarioGuardado && estadisticas && excelencia) {
             String salida = "";

            boolean otro = true;

            try {
                FileInputStream archivo
                        = new FileInputStream(nombreBinario);
                ObjectInputStream entrada = new ObjectInputStream(archivo);
                while (otro) {
                    Estudiante estudiante = new Estudiante();
                    try {
                        estudiante = (Estudiante) entrada.readObject();
                        salida += estudiante.toString() + "\n";
                    } catch (IOException io) {
                        JOptionPane.showMessageDialog(null, salida);
                        otro = false;
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
                archivo.close();
                mostrar = true;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al abrir el archivo: "
                        + nombreBinario);
            }
            
            salida = "";

            otro = true;

            try {
                FileInputStream archivo
                        = new FileInputStream(nombreBinario);
                ObjectInputStream entrada = new ObjectInputStream(archivo);
                while (otro) {
                    Estudiante estudiante = new Estudiante();
                    try {
                        estudiante = (Estudiante) entrada.readObject();
                        if (estudiante.getPromedio() >= 90) {
                            salida += estudiante.toString() + "\n";
                        }

                    } catch (IOException io) {
                        JOptionPane.showMessageDialog(null, salida);
                        otro = false;
                    } catch (ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                }
                archivo.close();
                excelencia = true;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error al abrir el archivo: "
                        + nombreBinario);
            }
            
            JOptionPane.showMessageDialog(null, "Calculo Diferencial: " + matrizCalificaciones[20][0]
                    + "\nFundamentos de programacion: " + matrizCalificaciones[20][1]
                    + "\nMatematicas Discretas: " + matrizCalificaciones[20][2]
                    + "\nIntroducción a las TICS: " + matrizCalificaciones[20][3]
                    + "\nTaller de ética: " + matrizCalificaciones[20][4]
                    + "\nFundamentos de investigacion" + matrizCalificaciones[20][5]
                    + "\nPromedio General: " + matrizCalificaciones[20][6]);
            estadisticas = true;
            
        } else {
            JOptionPane.showMessageDialog(null, "Aun faltan opciones por realizar antes de ver los reportes.");
        }
    }//GEN-LAST:event_botonReportesActionPerformed

    private void botonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_botonSalirActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonCalcular;
    private javax.swing.JButton botonCargar;
    private javax.swing.JButton botonEstadisticas;
    private javax.swing.JButton botonExcelencia;
    private javax.swing.JButton botonGuardar;
    private javax.swing.JButton botonMostrar;
    private javax.swing.JButton botonReportes;
    private javax.swing.JButton botonSalir;
    private javax.swing.JTextField campoNombreArchivo;
    private javax.swing.JTextField campoNombreBinario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
